class RouterName {
  // static const searchRecipeScreen = "/searchRecipeScreen";
  static const searchRecipe = "/searchRecipe";
  static const recipeDetails = "/recipeDetails";
}
