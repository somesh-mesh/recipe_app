import 'dart:async';
import 'package:demo_flutter/model/response_model/search_recipe_list_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();

  factory DatabaseHelper() => _instance;

  DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await initDatabase();
    return _database!;
  }

  Future<Database> initDatabase() async {
    String path = join(await getDatabasesPath(), 'recipes.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE recipes (
            id INTEGER PRIMARY KEY,
            title TEXT,
            image TEXT
            image_type TEXT
          )
        ''');
      },
    );
  }


  Future<void> saveResultsToSQLite(List<Results>? results) async {
    final Database db = await database;
    await db.delete('recipes');
    for (Results result in results!) {
      await db.insert('recipes', result.toJson());
    }
  }

  Future<List<Results>> retrieveResultsFromSQLite() async {
    final Database db = await database;
    final List<Map<String, dynamic>> maps = await db.query('recipes');
    return List.generate(maps.length, (index) {
      return Results(
        id: maps[index]['id'],
        title: maps[index]['title'],
        image: maps[index]['image'],
        imageType: maps[index]['image_type'],
      );
    });
  }

}


