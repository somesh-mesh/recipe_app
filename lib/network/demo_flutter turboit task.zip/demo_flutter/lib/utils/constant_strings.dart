class ConstantString{
  static const String apiKey = 'a308fccdee5f457aa5662543f512e405';
  static const String noDataFound = 'No Data Found';
  static const String recipeDetails = 'Recipes';
  static const String failToLoadData = 'Failed to load data';
}