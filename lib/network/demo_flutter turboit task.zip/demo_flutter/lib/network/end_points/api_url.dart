class APIUrl {
  static String baseUrl = "https://api.spoonacular.com";
  static String complexSearch = '$baseUrl/recipes/complexSearch/';
  static String recipeDetails = '$baseUrl/recipes';
  static String searchQuery = '$baseUrl/recipes/complexSearch';
}
